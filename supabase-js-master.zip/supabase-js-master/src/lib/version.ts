export const version = '0.0.0-automated'
